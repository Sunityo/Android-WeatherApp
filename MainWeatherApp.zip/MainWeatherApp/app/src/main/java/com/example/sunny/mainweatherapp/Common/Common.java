package com.example.sunny.mainweatherapp.Common;

import android.location.Location;



public class Common {

    // Adding the API key from openWeatherMap
    public static final String APP_ID = "bcdf16420fc6f5b1c55b538a5e4fc5a7";

    // the current location is set a null, because Dexter will call for the location of the user.
    public static Location current_location=null;
}
