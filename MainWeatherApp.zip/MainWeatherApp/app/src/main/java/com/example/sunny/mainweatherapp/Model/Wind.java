package com.example.sunny.mainweatherapp.Model;



public class Wind {

    private int speed;

    public Wind(){

    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
